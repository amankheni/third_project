import 'package:flutter/cupertino.dart';

class TextFormFieldController {
  static TextEditingController txtNameController = TextEditingController();
  static TextEditingController txtSurnameController = TextEditingController();
  static TextEditingController txtPhoneNoController = TextEditingController();
  static TextEditingController txtEmaileController = TextEditingController();
  static TextEditingController txtAgeController = TextEditingController();
}
